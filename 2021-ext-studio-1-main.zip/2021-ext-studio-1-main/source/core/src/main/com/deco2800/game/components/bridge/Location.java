package com.deco2800.game.components.bridge;

public interface Location {
    int getTop();
    int getMid();
    int getBot();
}
