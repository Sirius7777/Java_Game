# Welcome to DECO2800 Studio 1 (External)!

![Build and Release](https://github.com/UQdeco2800/2021-ext-studio-1/actions/workflows/gradle_release.yaml/badge.svg)

![Game Unit Tests](https://github.com/UQdeco2800/2021-ext-studio-1/actions/workflows/gradle_tests.yaml/badge.svg)

## Game Description
In Ragnarok Racer, you are playing Thor and fight (or dodge) to make your own way on the rainbow bridge to finally meet your evil sister Hela.

## Game Controls
#####Press W for going up 1 lane
#####Press S for going down 1 lane
#####Press Q for moving to the top lane
#####Press E for moving to the bottom lane
#####Press Space for attacking

## Sonar Cloud
https://sonarcloud.io/dashboard?id=UQdeco2800_2021-ext-studio-1
